// Tests compatibility with iosfwd
#include "../src/pugixml.hpp"
#include <iosfwd>
